'use client';

import { useTokenRefresh } from '@/hooks/useAuth';

const TokenRefresh = () => {

  useTokenRefresh(); // Trigger token refresh

  return null;
};

export default TokenRefresh;
